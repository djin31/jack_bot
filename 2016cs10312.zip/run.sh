#!/bin/bash
python jack_bot.py $1 > Policy.txt
