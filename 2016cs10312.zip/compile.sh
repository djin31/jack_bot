#!/bin/bash
rm *.pyc
echo "Jack_Bot is ready to run!"
