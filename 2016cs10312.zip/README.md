# jack_bot
AI bot that produces strategy for a BlackJack game with rigged probabilities of face cards

## How to run
python jack_bot.py <p-value> [-d]
